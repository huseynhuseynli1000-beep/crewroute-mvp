
export const SERVICES = [
  {id:'cleaning', title:'Home cleaning', detail:'A fresh start for your space', icon:'sparkles', rate:38, duration:2, tag:'Popular'},
  {id:'furniture', title:'Furniture assembly', detail:'Built right, without the hassle', icon:'wrench', rate:45, duration:2, tag:''},
  {id:'moving', title:'Moving help', detail:'Heavy lifting, handled', icon:'truck', rate:55, duration:3, tag:'In demand'},
  {id:'handyman', title:'Handyman', detail:'Small fixes, big relief', icon:'hammer', rate:49, duration:2, tag:''},
  {id:'yard', title:'Yard & outdoor', detail:'Give your outdoors some love', icon:'leaf', rate:42, duration:2, tag:''},
  {id:'delivery', title:'Pickup & delivery', detail:'Get it from A to B', icon:'package', rate:32, duration:1, tag:''}
];

const KEY='crewroute_jobs_v1';
const USER_KEY='crewroute_client_id';
export const uid=()=>globalThis.crypto?.randomUUID?.() ?? `id-${Date.now()}-${Math.random().toString(16).slice(2)}`;
export const clientId=()=>{let id=localStorage.getItem(USER_KEY); if(!id){id=uid();localStorage.setItem(USER_KEY,id)}return id};
export const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(Number(n)||0);
export const time=s=>new Date(s).toLocaleString('en-US',{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'});

const sample=()=>({
  id:'demo-sample',owner_id:'demo',service_id:'furniture',service_title:'Furniture assembly',address:'125 W State St, West Lafayette, IN',notes:'Assemble a desk and two bookshelves.',scheduled_for:new Date(Date.now()+86400000).toISOString(),hours:2,total:90,status:'in_progress',worker_name:'Alex Morgan',worker_initials:'AM',worker_rating:4.9,worker_x:51,worker_y:48,progress:0.64,created_at:new Date(Date.now()-7200000).toISOString(),demo:true
});

function load(){try{const raw=JSON.parse(localStorage.getItem(KEY));return Array.isArray(raw)?raw:[sample()]}catch{return [sample()]}}
function save(jobs){localStorage.setItem(KEY,JSON.stringify(jobs));window.dispatchEvent(new CustomEvent('crewroute:change'));}

export class CrewStore {
  constructor(){this.jobs=load();this.listeners=new Set();this.mode='demo';this.channel=typeof BroadcastChannel!=='undefined'?new BroadcastChannel('crewroute_sync'):null;this.channel?.addEventListener('message',()=>this.refresh());window.addEventListener('storage',e=>{if(e.key===KEY)this.refresh()});this.client=null;this.subscription=null;this.poll=null;this.currentUser=null;}
  subscribe(fn){this.listeners.add(fn);return()=>this.listeners.delete(fn)}
  emit(){this.listeners.forEach(fn=>fn(this.jobs))}
  refresh(){if(this.mode==='demo'){this.jobs=load();this.emit()}}
  async init(){
    const url=window.CREWROUTE_CONFIG?.supabaseUrl;const key=window.CREWROUTE_CONFIG?.supabaseAnonKey;
    if(!url||!key){this.emit();return}
    try{
      const {createClient}=await import('https://esm.sh/@supabase/supabase-js@2');
      this.client=createClient(url,key,{auth:{persistSession:true,autoRefreshToken:true}});
      let {data:{session}}=await this.client.auth.getSession();
      if(!session){const result=await this.client.auth.signInAnonymously();if(result.error)throw result.error;session=result.data.session;}
      this.currentUser=session.user.id;this.mode='cloud';
      await this.sync();
      this.subscription=this.client.channel('crewroute-changes').on('postgres_changes',{event:'*',schema:'public',table:'jobs'},()=>this.sync()).subscribe();
      this.poll=setInterval(()=>this.sync(),15000);
    }catch(err){console.warn('Supabase unavailable; falling back to local demo:',err);this.mode='demo';this.client=null;this.emit()}
  }
  async sync(){if(!this.client)return;const {data,error}=await this.client.from('jobs').select('*').order('created_at',{ascending:false});if(error){console.warn('Sync failed',error.message);return}this.jobs=data||[];this.emit()}
  async create(fields){const job={id:uid(),owner_id:this.mode==='cloud'?this.currentUser:clientId(),status:'requested',worker_name:null,worker_initials:null,worker_rating:null,worker_x:14,worker_y:77,progress:0,created_at:new Date().toISOString(),...fields};
    if(this.mode==='cloud'){const {error}=await this.client.from('jobs').insert(job);if(error)throw error;await this.sync()}else{this.jobs=[job,...this.jobs];save(this.jobs);this.channel?.postMessage('update');this.emit()}return job;}
  async update(id,patch){if(this.mode==='cloud'){const {error}=await this.client.from('jobs').update(patch).eq('id',id);if(error)throw error;await this.sync()}else{this.jobs=this.jobs.map(j=>j.id===id?{...j,...patch}:j);save(this.jobs);this.channel?.postMessage('update');this.emit()}}
  async reset(){if(this.mode==='cloud')throw Error('Reset is available in demo mode only');this.jobs=[sample()];save(this.jobs);this.channel?.postMessage('update');this.emit()}
  destroy(){this.subscription?.unsubscribe();if(this.poll)clearInterval(this.poll);this.channel?.close()}
}
