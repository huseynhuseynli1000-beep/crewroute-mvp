window.CREWROUTE_CONFIG = { supabaseUrl: "", supabaseAnonKey: "" };
