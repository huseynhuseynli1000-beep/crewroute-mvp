# CrewRoute — services marketplace + worker tracking

A polished, responsive **web-only MVP** for an engineering take-home: TaskRabbit-style local service booking plus Uber-style task status and worker tracking.

## What works

- Customer: browse **six services**, see hourly pricing, enter date/time/address/notes, calculate an estimate, and create a booking.
- Worker: view available requests, accept a job, start a journey, mark arrival, and finish the work.
- Tracking: customer-facing status timeline, assigned helper profile, schematic route map, and animated demo worker movement.
- Dashboard: active jobs, finished jobs, estimated spend, and booking history.
- Data: instant **localStorage demo** (no credentials required), synchronized across tabs; optional **Supabase** Postgres, Auth anonymous sign-in, and realtime updates.
- Responsive: desktop, tablet, and phone.

## Run locally

Prerequisites: Python 3 (for the local static web server). No npm install or bundling needed.

```bash
python3 -m http.server 5173
```

Open http://localhost:5173 in your browser. You can use the site immediately in **Interactive demo** mode without external services.

### End-to-end demo (under 2 minutes)

1. Go to **Explore services** and choose *Home cleaning*.
2. Enter a street address, pick a date and hours, and confirm. (No real payment is taken.)
3. Go to **Worker console** and accept the new request.
4. Click **Start journey**, then **Move demo worker along route**.
5. Switch to **Live tracking** and watch the marker move as status changes.
6. Return to Worker console: **Arrived · start job** → **Mark complete**.
7. Review the completed task in **My bookings**.

If you want to start fresh, open **How it works → Reset demo data**.

## Optional Supabase cloud mode

1. Create a Supabase project.
2. In **Authentication → Providers → Anonymous**, enable anonymous sign-ins.
3. Paste and run [`supabase/schema.sql`](supabase/schema.sql) in the SQL editor.
4. Edit `config.js` (client-side public configuration) to provide your project URL and **anon/publishable** key:

   ```js
   window.CREWROUTE_CONFIG = {
     supabaseUrl: "https://YOUR-PROJECT.supabase.co",
     supabaseAnonKey: "YOUR-ANON-OR-PUBLISHABLE-KEY"
   };
   ```

5. Refresh the website. The header should display **Supabase connected**. Open the site in two browsers to see shared bookings.

**Security:** this SQL intentionally uses permissive authenticated demo policies to let the same user act as both a customer and a worker. It exposes booking addresses to authenticated demo users. **Do not enter real personal addresses in cloud demo mode**. Before production, implement verified worker onboarding, distinct customer/worker roles, assignment ownership, status-transition authorization on the server, private address access, anti-abuse controls, and secure location consent. Never put a Supabase `service_role` key in `VITE_*` variables.

## Deploy to GitHub + Render

1. Create a GitHub repository and push this folder:

   ```bash
   git init
   git add .
   git commit -m "Build CrewRoute marketplace MVP"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/crewroute-mvp.git
   git push -u origin main
   ```

2. Log in to [Render](https://dashboard.render.com/), choose **New → Blueprint**, and select your repository. `render.yaml` provisions a static site.
3. If using Supabase, set the public values in `config.js` and commit/deploy. Otherwise, leave its values blank for localStorage demo. The anon key is designed to be public; **never put a service-role key in client config**.
4. Render provides a public `.onrender.com` site address. **This assistant cannot provision your GitHub/Supabase/Render accounts on your behalf from this package.**

## Architecture

```
index.html                Single-page entry
src/icons.js              Self-contained inline icon SVGs
src/app.js                UI screens, interactions, booking flow, simulated tracker
src/store.js              Data model, local persistence, optional Supabase client
src/style.css             Responsive UI / map styling
supabase/schema.sql       SQL table, row-level security, Realtime publication
render.yaml               Render static-site definition
config.js                  Optional public Supabase configuration
```

The frontend is self-contained plain JavaScript and CSS; no Node, NPM, or build process is required. The optional Supabase JavaScript SDK loads from a CDN only when cloud mode is enabled. The map is a **schematic SVG/CSS demonstration**, not a street-accurate map or GPS feed. Demo marker movement is simulated, not a real driver-tracking claim. The Supabase mode synchronizes worker coordinates stored in Postgres, but the sample does not contain mobile GPS collection or route mapping. Estimates are illustrative; it has **no payment processing, notifications, verified worker marketplace, or real dispatch algorithm**.

## Choices and next steps

**MVP focus:** prioritize one complete request-to-completion experience over building many shallow features. Keep the journey testable without API accounts while providing a straightforward path to hosted persistence. UI uses no paid image, map, or location APIs.

**Production next steps:** implement real user registration and verified roles; secure RLS and server-side status transitions; real dispatch/matching; worker opt-in GPS and a geospatial map (Mapbox/MapLibre); Stripe Connect; push notifications; accurate ETA and geocoding; tests, observability, and accessibility audit.

## Quality checks

```bash
node --check src/app.js
node --check src/store.js
node --check src/icons.js
```

There is no implicit promise of automatic deployment, reliable real-time GPS, or production-grade customer data security.
