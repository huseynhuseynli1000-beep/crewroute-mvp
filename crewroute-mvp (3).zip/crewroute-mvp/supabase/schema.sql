-- CrewRoute prototype schema. Execute in the Supabase SQL editor.
-- Enable Auth -> Providers -> Anonymous Sign-ins before enabling Cloud mode.
-- This is an evaluation prototype: worker access is available to any authenticated
-- anonymous user. Add verified worker accounts and server-side role checks before
-- processing actual customer jobs or locations.

create extension if not exists pgcrypto;
create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  service_id text not null check(service_id in ('cleaning','furniture','moving','handyman','yard','delivery')),
  service_title text not null,
  address text not null check(char_length(address) between 8 and 160),
  notes text not null default '' check(char_length(notes)<=500),
  scheduled_for timestamptz not null,
  hours integer not null check(hours between 1 and 12),
  total numeric(10,2) not null check(total>=0),
  status text not null default 'requested' check(status in ('requested','accepted','en_route','in_progress','completed','cancelled')),
  worker_name text,
  worker_initials text,
  worker_rating numeric(3,1),
  worker_x numeric(5,2) not null default 14,
  worker_y numeric(5,2) not null default 77,
  progress numeric(4,3) not null default 0 check(progress between 0 and 1),
  created_at timestamptz not null default now()
);

create index if not exists jobs_owner_created_idx on public.jobs(owner_id,created_at desc);
create index if not exists jobs_status_idx on public.jobs(status);
alter table public.jobs enable row level security;

-- Demo marketplace: any signed-in user can view and update all job status fields.
-- This deliberately supports role switching without onboarding for evaluation.
-- DO NOT ship this as a production authorization model.
drop policy if exists "demo authenticated read" on public.jobs;
create policy "demo authenticated read" on public.jobs for select to authenticated using (true);
drop policy if exists "demo customer insert" on public.jobs;
create policy "demo customer insert" on public.jobs for insert to authenticated
with check (owner_id=auth.uid());
drop policy if exists "demo authenticated update" on public.jobs;
create policy "demo authenticated update" on public.jobs for update to authenticated
using (true) with check (true);

-- Realtime: replication publication. Run once, may already be configured.
do $$ begin
  alter publication supabase_realtime add table public.jobs;
exception when duplicate_object then null;
end $$;
